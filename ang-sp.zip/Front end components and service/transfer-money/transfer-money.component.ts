import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service.js';
@Component({
  selector: 'app-transfer-money',
  templateUrl: './transfer-money.component.html',
  styleUrls: ['./transfer-money.component.css']
})
export class TransferMoneyComponent implements OnInit {
  array =[];
  successflag=false
  flag = false
  constructor(private service: ClientService) { }

  ngOnInit() {
  }

  find(number1, number2) {
    this.service.findaccounts(number1,number2).subscribe(data=> {this.array=data});
    this.flag = true
  }
  transfer(number1, number2, amount) {
    this.array.splice(0,5);
  this.service.transfer(number1,number2,amount).subscribe(data=>{this.array=data})
  }
}
