import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CustserviceService {
  id = 1;
  constructor(private httpClient: HttpClient) { }

  changePassword(oldPassword, newPassword, confirmPassword): Observable<number> {
        const url = 'http://localhost:9092/' + '/changepassword/' + this.id + '/' +
     oldPassword + '/' + newPassword + '/' + confirmPassword + ' ';
    return this.httpClient.put<number>(url, '');
   }

}
