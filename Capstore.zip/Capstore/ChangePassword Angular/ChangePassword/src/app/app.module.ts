import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { ChangepwdComponent } from './changepwd/changepwd.component';
import { CustserviceService } from './custservice.service';


@NgModule({
  declarations: [
    AppComponent,
    ChangepwdComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [CustserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
