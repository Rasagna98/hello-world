export class Customer {
  customerID: number;
  customerPassword: String;
  customerName: String;
  customerMobile: String;
  customerEmail: string;
  customerWallet: number;
  customerHistory: string;
  cartID: number;
  EncryptedPassword: string ;
  }
