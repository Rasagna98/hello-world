import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {ChangepwdComponent} from './changepwd/changepwd.component';
// import{MainComponent}from './main/main.component';

import { from } from 'rxjs';

const routes: Routes = [

  {path: 'ChangePassword', component: ChangepwdComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
