package com.capgemini.capstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.capstore.bean.CapgCustomer;
import com.capgemini.capstore.service.CapgCustomerService;

@RestController
public class ControllerChangePassword {
	
	@Autowired
	CapgCustomerService service;
	
	@PostMapping(path="password/add",consumes="application/json")
	public void add(@RequestBody CapgCustomer customers) {
		service.add(customers);		
	}
	
	@PutMapping(value="/changepassword/{id}/{oldpassword}/{newpassword}/{confirmpassword}")
	  public String changepwd(@PathVariable int id,@PathVariable String oldpassword,@PathVariable String newpassword,@PathVariable String confirmpassword) {
		boolean flag =  service.changePwd(id, oldpassword, newpassword, confirmpassword);
		String result;
		if(flag) {
			result = "Successfully changed password";
		}
		else {
			result = "Please enter correct password";
		}
		return result;
			
	
		  
	  }
	
	/*@RequestMapping(value = "changePassword1")
	public ModelAndView changePassword(@RequestParam("customerId") int customerId) {

		return new ModelAndView("changePassword", "customerId", customerId);
	}

	@RequestMapping(value = "changePasswordSuccess1/{customerId}")
	public ModelAndView changePasswordSuccess(@PathVariable int customerId,
			@RequestParam("oldPassword") String oldPassword, @RequestParam("newPassword") String newPassword,
			@RequestParam("confirmNewPassword") String confirmNewPassword) {

		CapgCustomer customer = service.findCustomerId(customerId);
		service.changePassword(customer, newPassword);
		System.out.println(customer.getConfirmPassword());
		return new ModelAndView("changePasswordSuccess");
	}*/
	
	/*@PutMapping(path="password/add",consumes="application/json")
	public void update(CapgCustomer customers) {
		
		//service.updatePassword(name, password);
		
		
	}*/
	
	
	/* @PostMapping(value = "/sysusers/changePassword")
	 public ResponseEntity<?> updatePassword(@RequestBody User user) throws 
	 Exception {
	     service.updatePassword(user.getName(), 
	 user.getPassword());
	     return new ResponseEntity<>(new CustomResponse(CustomResponse.APIV, 201, true, "Password updated successfully"), HttpStatus.OK);
	 }*/
	
	
}
