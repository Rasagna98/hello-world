package com.capgemini.capstore.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.capgemini.capstore.bean.CapgCustomer;

@Repository
public class ChangePasswordImpl implements ChangePasswordInterface {
	
	@Autowired
	ChangePasswordDao repo;
	
	@Override
	public void changePwdDao(CapgCustomer customer) {
		
				repo.save(customer);	
				
	}
	

	@Override
	public void addDao(CapgCustomer customers) {
		// TODO Auto-generated method stub
		repo.save(customers);
	}


	@Override
	public CapgCustomer getCustomer(int customerId) {
		return repo.findById(customerId).orElse(null);
	}

}
