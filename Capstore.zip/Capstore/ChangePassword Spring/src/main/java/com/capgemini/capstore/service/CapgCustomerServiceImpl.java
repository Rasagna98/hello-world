package com.capgemini.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.capstore.bean.CapgCustomer;
import com.capgemini.capstore.dao.ChangePasswordImpl;

@Service
public class CapgCustomerServiceImpl implements CapgCustomerService {
	
	@Autowired
	//ChangePasswordDao repo;
	ChangePasswordImpl dao;
	
	@Autowired
	ChangePasswordImpl changePasswordDao;
	@Override
	public void add(CapgCustomer customers) {
		
		dao.addDao(customers);		
	}	
	
	@Override
	public boolean changePwd(int customerID, String oldpassword, String newpassword, String confirmpassword) {
		CapgCustomer customer = changePasswordDao.getCustomer(customerID);
		boolean flag = false;		
		if (newpassword.equals(confirmpassword)) 
		{
			System.out.println("New Password and Confirm password are same");
			if(newpassword.equals(oldpassword)==false) {
				System.out.println("New Password is not same as  Old Password ");
			
				customer.setCustomerPassword(newpassword);
				changePasswordDao.changePwdDao(customer);
				
			//	dao.save(customer);	
				flag = true;
		}
			else {
				flag = false;
			}
	}
		else {
			flag = false;
		}
		return flag;
	}
	
		//return dao.changePwdDao(customerID, oldpassword, newpassword, confirmpassword);
		
}
