package com.capgemini.capstore.service;

import com.capgemini.capstore.bean.CapgCustomer;

public interface CapgCustomerService {	
	
	public boolean changePwd(int customerID, String oldpassword, String newpassword, String confirmpassword);
	public void add(CapgCustomer customers);	
	
}