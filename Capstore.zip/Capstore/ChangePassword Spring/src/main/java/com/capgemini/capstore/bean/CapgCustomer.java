package com.capgemini.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;
@Entity
@Table(name="capgcustomer") //capg_customer
public class CapgCustomer {
	@Id	
		
	//@Column(name="CustomerID")
	private int customerID;
	//@Column(name="CustomerPassword")
	private String customerPassword;
	
	private String customerName;
	private String customerMobile;
	private String customerEmail;
	private	double customerWallet;
	private String customerHistory;
	private int cartID;
	private String EncryptedPassword;
	/*@Column(name="NewPassword")
	private String newPassword;
	@Column(name="ConfirmPassword")
	private String confirmPassword;*/
	public int getCustomerID() {
		return customerID;
	}
	public void setCustomerID(int customerID) {
		this.customerID = customerID;
	}
	public String getCustomerPassword() {
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	/*public String getNewPassword() {
		return newPassword;
	}
	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}
	public String getConfirmPassword() {
		return confirmPassword;
	}
	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}*/	
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerMobile() {
		return customerMobile;
	}
	public void setCustomerMobile(String customerMobile) {
		this.customerMobile = customerMobile;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public double getCustomerWallet() {
		return customerWallet;
	}
	public void setCustomerWallet(double customerWallet) {
		this.customerWallet = customerWallet;
	}
	public String getCustomerHistory() {
		return customerHistory;
	}
	public void setCustomerHistory(String customerHistory) {
		this.customerHistory = customerHistory;
	}
	public int getCartID() {
		return cartID;
	}
	public void setCartID(int cartID) {
		this.cartID = cartID;
	}
	public String getEncryptedPassword() {
		return EncryptedPassword;
	}
	public void setEncryptedPassword(String encryptedPassword) {
		EncryptedPassword = encryptedPassword;
	}
	@Override
	public String toString() {
		return "CapgCustomer [customerID=" + customerID + ", customerPassword=" + customerPassword + ", customerName="
				+ customerName + ", customerMobile=" + customerMobile + ", customerEmail=" + customerEmail
				+ ", customerWallet=" + customerWallet + ", customerHistory=" + customerHistory + ", cartID=" + cartID
				+ ", EncryptedPassword=" + EncryptedPassword + "]";
	}
	
	

}
