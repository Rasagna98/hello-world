package com.capgemini.capstore.dao;

import com.capgemini.capstore.bean.CapgCustomer;

public interface ChangePasswordInterface {
	public void changePwdDao(CapgCustomer customer);
	public void addDao(CapgCustomer customers);
	public CapgCustomer getCustomer(int customerId);
}
