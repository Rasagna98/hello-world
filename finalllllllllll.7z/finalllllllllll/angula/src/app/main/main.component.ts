import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';
import { Customer } from '../customer';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit {
prod1:Product;
prod2:Product;
item:string
custo:Customer
  constructor(private router: Router, private userService: CustserviceService) { }

  ngOnInit() {
   this.getCustomerDetails()

  }

  search(item){
    this.userService.search(item).subscribe(data => {
      this.prod1=data;
     }
     )
 console.log(this.prod1)
  };
  sort(str){
    if(str=="LOW to HIGH"){
      str="lth"
    }
    else if(str=="HIGH to LOW"){
      str="htl"
    }
    else if(str=="MOST VIEWED"){
      str="mv"
    }
    else if(str=="TOP RATED"){
      str="tr"
    }
    this.userService.sort(str).subscribe(data => {
      this.prod1=data;
     }
     )
    
  };

  getCustomerDetails(){
    this.userService.getCustomerDetails().subscribe(data =>{      
      this.custo=data;
    })
    };

  



}
