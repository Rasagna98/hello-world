import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';
@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  prod:Product;
  constructor(private router: Router, private userService: CustserviceService) {

  }
  ngOnInit() {
    this.getAllCartItems();
  }
getAllCartItems(){
  this.userService.getAllCartItems().subscribe(data => {
    this.prod=data;
})
};

RemoveFromCart(pro_id:number){
  this.userService.RemoveFromCart(pro_id).subscribe(data => {
    if(data==1){
      alert("Successfully DELETED")
    this.router.navigate(['/wishlist'])

    }
})
};
generateInvoice(pro){
  this.userService.generateInvoice(pro).subscribe(result=>{
    console.log(result);
  });
}}
