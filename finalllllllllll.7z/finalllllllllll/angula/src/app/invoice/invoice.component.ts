import { Component, OnInit } from '@angular/core';
import {CustserviceService} from '../custservice.service';
import { Router } from '@angular/router';
import { Product } from '../Product';
import { ThrowStmt } from '@angular/compiler';

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
prod:Product
bill:number
cgst:number
sgst:number
fbill:number
obill:number

  constructor(private router: Router, private userService: CustserviceService) { }

  ngOnInit() {
    this.invoice();
  
  }

invoice(){
  this.userService.invoice().subscribe(data => {
    this.prod=data;
})
this.billing()

};
billing(){
  this.userService.billing().subscribe(data =>{
    this.bill=data;
    this.cgst=((data*5)/100);
    this.sgst=((data*5)/100);
    data=data+this.sgst+this.cgst;
    this.obill=data
    this.fbill=data
    
  })
  
  
};

coupon(c){
  if(c=="CAPSTORE50"){
    this.fbill=this.fbill-((this.fbill*10)/100)
  }
  else if(c=="CAPSTORE30"){

    this.fbill=this.fbill-((this.fbill*20)/100)
  }
  else{
    this.fbill=this.fbill
  }
};


}
