import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import{CustserviceService} from '../custservice.service'

@Component({
  selector: 'app-changepwd',
  templateUrl: './changepwd.component.html',
  styleUrls: ['./changepwd.component.css']
})
export class ChangepwdComponent implements OnInit {

  response:number;
  constructor(private router: Router,private userService:CustserviceService ) { }

  ngOnInit() {
  }
  changePassword(oldPassword ,newPassword,confirmPassword){
    console.log(oldPassword,confirmPassword,newPassword)
    if(newPassword!=confirmPassword){
      alert("PASSWORDS DOESNT MATCH")
    }
else if(newPassword==oldPassword && oldPassword==confirmPassword){
  alert("password must be different")
}

else{
    this.userService.changePassword(oldPassword ,newPassword,confirmPassword).subscribe(data=>
{
  if(data==1){
    alert("SUCCESSFULLY CHANGED")
    this.router.navigate(['/Main']);
  }
  else{
    alert("PLEASE ENTER IN A PROPER WAY")
  }
  
});
  }

  }



}
