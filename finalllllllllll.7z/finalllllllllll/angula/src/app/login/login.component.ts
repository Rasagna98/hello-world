import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustserviceService } from '../custservice.service';
import { Product } from '../Product';


@Component({
 
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  products:Product[];
  prod:Product;
  img_url:string;
  constructor(private router: Router, private userService: CustserviceService) {

  }

  ngOnInit() {

  }

  login(uName, pwd) {
    this.userService.login(uName, pwd).subscribe(data => {
      this.userService.setid(data);
      alert(this.userService.getid())
      this.router.navigate(['/Main']);
    }, error => { alert("Wrong credentials") });
  };

 


  }


