export class Product {

    prod_id: number;
    prod_name: string;
    prod_img_link: string;
    prod_desc: string;
    prod_price: string;


    
}
