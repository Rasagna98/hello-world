package com.cg.Exception;

public class CapStoreException extends Exception{
	public CapStoreException()
	{
		
	}
	public CapStoreException(String msg)
	{
		super(msg);
	}

}



