package com.cg.service;

import java.util.List;
import java.util.Optional;

import com.cg.Exception.CapStoreException;
import com.cg.bean.Cart;
import com.cg.bean.Customer;
import com.cg.bean.Invoice;
import com.cg.bean.Product;
import com.cg.bean.Wishlist;

public interface CustService {
	 public int loginByUsername(String uName, String pwd) throws CapStoreException;
	 public int changePwd( int id,String oldpassword, String newpassword, String confirmpassword);
	 public void addToCart(Product pro,int id) ;
	 List<Cart> getAllCartItems(int id);
	 List<Wishlist> getAllItems(int id);
	public void  addToWishlist(Product pro, int id);
	public void removeFromWishlist(int id,int id1);
	public void removeFromCart(int id, int pid);
	public void buyNow(Product pro,int id);
	public List<Invoice> getInvoice(int id);
	public double getInvoiceb(int id);
	public int forgotPwd( String uName, String newpassword, String confirmpassword);
	public Optional<Customer> getCustById(int id);
	
}
