package com.cg.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Exception.CapStoreException;
import com.cg.bean.Cart;
import com.cg.bean.Customer;
import com.cg.bean.Invoice;
import com.cg.bean.Product;
import com.cg.bean.Wishlist;
import com.cg.service.CustService;
import com.cg.service.ProdService;
@CrossOrigin("http://localhost:4200")
@RestController
public class CustController {
	@Autowired
	CustService ser;
	@Autowired
	ProdService pSer;
	  @RequestMapping(value = "/login/{username}/{password}")
  	public int  lo(@PathVariable String username,@PathVariable String password) throws CapStoreException {
  		return ser.loginByUsername(username, password);
  	}
	
	  @RequestMapping(value ="/productsMen")
	  	public List<Product> productM() {
	  		return pSer.getAllProdsM();
	  	}
	 @RequestMapping(value = "/productsWomen")
	  	public List<Product> productW() {
	  		return pSer.getAllProdsW();
	  	}
	  @RequestMapping(value = "/productsKids")
	  	public List<Product> productK() {
	  		return pSer.getAllProdsK();
	  	}
	  @RequestMapping(value = "/{id}/Cart")
	  	public List<Cart> getAllCartItems(@PathVariable int id) {
	  		return ser.getAllCartItems(id);
	  	}
	  @RequestMapping(value = "/{id}/addtocart", method = RequestMethod.POST)
		public void addToCart(@RequestBody Product pro ,@PathVariable int id) {
			 ser.addToCart(pro,id);
		}
	  @RequestMapping(value = "/{id}/Wishlist")
	  	public List<Wishlist> getAllItems(@PathVariable int id) {
	  		return ser.getAllItems(id);
	  	}
	  @RequestMapping(value = "/{id}/addtoWishlist", method = RequestMethod.POST)
		public void addToWishlist(@RequestBody Product pro,@PathVariable int id) {
			 ser.addToWishlist(pro,id);
		}
	  @RequestMapping(value = "/{id}/buyNow", method = RequestMethod.POST)
		public void buyNow(@RequestBody Product pro, @PathVariable int id) {
			 ser.buyNow(pro,id);
		}
	  
	  @RequestMapping(value = "/{id}/invoice")
	  	public List<Invoice> getInvoice(@PathVariable int id) {
	  		return ser.getInvoice(id);
	  	}
	  
	  @RequestMapping(value = "/{id}/invoiceb")
	  	public double getInvoiceb(@PathVariable int id) {
	  		return ser.getInvoiceb(id);
	  	}
	  
 @DeleteMapping(value = "/{id}/{pid}/removefromwishlist")
	  	public void removeFromWishlist(@PathVariable int id,@PathVariable int pid) {
	  		 ser.removeFromWishlist(id,pid);
	  	}
	  
 @DeleteMapping(value = "/{id}/{pid}/removefromcart")
	public void removeFromCart(@PathVariable int id,@PathVariable int pid) {
		 
		 ser.removeFromCart(id,pid);
	}
 
	  @RequestMapping(value = "/search/{item}")
	  	public List<Product> getSearchItems(@PathVariable String item) {
	  		return pSer.getSearchItems(item);
	  	}
	  
	  @RequestMapping(value = "/search/{item}/sortlth")
	  	public List<Product> getSort(@PathVariable String item) {
	  		return pSer.getSort(item);
	  	}
	  
	  @RequestMapping(value = "/search/{item}/sorthtl")
	  	public List<Product> getSort1(@PathVariable String item) {
	  		return pSer.getSort1(item);
	  	}
	  
	  @RequestMapping(value = "/search/{item}/sorttr")
	  	public List<Product> getSort2(@PathVariable String item) {
	  		return pSer.getSort2(item);
	  	}
	  @RequestMapping(value = "/search/{item}/sortmv")
	  	public List<Product> getSort3(@PathVariable String item) {
	  		return pSer.getSort3(item);
	  	}
	  
	  
	  
	  @PutMapping(value="/{id}/changepassword/{oldpassword}/{newpassword}/{confirmpassword}")
	  public int changepwd(@PathVariable int id,@PathVariable String oldpassword,@PathVariable String newpassword,@PathVariable String confirmpassword) {
		 if(ser.changePwd(id, oldpassword, newpassword, confirmpassword)==1) {
			 
			return 1;
			
			 
		 }
		 
		 return 0;
		  
	  }
	  
	  @PutMapping(value="/forgotPassword/{uName}/{newpassword}/{confirmpassword}")
	  public int forgotpwd(@PathVariable String uName,@PathVariable String newpassword,@PathVariable String confirmpassword) {
		
		 if(ser.forgotPwd( uName, newpassword, confirmpassword)==1) {
			 
			return 1;
			
			 
		 }
		 
		 return 0;
		  
	  }
	  @RequestMapping(value = "/{id}")
	  	public Optional<Customer> getCustById(@PathVariable int id) {
	  		return ser.getCustById(id);
	  	}
	  
	  
	  
}
