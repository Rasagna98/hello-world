package com.cg.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.bean.Cart;

@Repository
public interface CartDao extends JpaRepository<Cart, Integer> {
	@Query(value="SELECT * FROM Cart WHERE cust_id=:u",nativeQuery=true)
	List<Cart> findAll(@Param("u") Integer id);
	
	@Query(value="DELETE FROM Cart WHERE cust_id=:s AND prod_id=:u",nativeQuery=true)
	boolean deleteByImg_link(@Param("s") int id,@Param("u") int pid);

}
