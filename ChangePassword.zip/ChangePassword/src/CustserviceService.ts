import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CustserviceService {
  id: number;
  constructor(private httpClient: HttpClient) { }
  login(uName, pwd): Observable<number> {
   // let url = 'http://localhost:9003/login/' + uName + '/' + pwd;
    let url = 'C:/FLP/ChangePassword/src/customer.ts' + uName + '/' + pwd;
   return this.httpClient.get<number>('url');
  }

  changePassword(oldPassword, newPassword, confirmPassword): Observable<number> {


    // let url = 'http://localhost:9003/'+this.id+'/changepassword/'+oldPassword+'/'+newPassword+'/'+confirmPassword;
    let url = 'C:/FLP/ChangePassword/src/customer.ts'
    + this.id + '/changepassword/' + oldPassword + '/' + newPassword + '/' + confirmPassword;
    return this.httpClient.put<number>('url', '');
  }

  getid() {
    return this.id;
  }

  setid(id: number) {
    this.id = id;
  }
}
