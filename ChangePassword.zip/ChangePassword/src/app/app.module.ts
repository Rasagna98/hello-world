import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChangePwdComponent } from './change-pwd/change-pwd.component';
import { CustserviceService } from '../CustserviceService';

@NgModule({
  declarations: [
    AppComponent,
    ChangePwdComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [CustserviceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
