package com.capg.stepdefinition;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.WebPom;
import com.capg.pom.WebPomRegistration;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepdefinition {
	WebDriver driver;
	@Given("^user is on 'Paper Submission for capgemini' page$")
	public void user_is_on_Paper_Submission_for_capgemini_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 driver=WebPomRegistration.getWebDriver();
	        String url="file:///C:/VV%20AT%20M4_MPT%20Sample%20Que/registration.html";
	        driver.get(url);
	}

	@When("^user enters invalid first name$")
	public void user_enters_invalid_first_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("");
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	  
	}

	@Then("^displays 'Please fill the Full Name'$")
	public void displays_Please_fill_the_first_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		driver.close();
	  
	}

	@When("^user enters invalid email$")
	public void user_enters_invalid_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("");
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	}

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		driver.close();
	   
	}

	@When("^user enters invalid mobile number$")
	public void user_enters_invalid_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getFullNameField();
		userMobileNo.sendKeys("");
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();	
	}

	@Then("^display 'Please fill Mobile No\\.'$")
	public void display_Please_fill_Mobile_No() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Mobile No.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		
	}

	@When("^user enters wrong mobile number$")
	public void user_enters_wrong_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9541236");
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	}

	@Then("^display 'Please enter valid Mobile Number'$")
	public void display_Please_enter_valid_Mobile_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please enter valid Contact no.";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
		
	   
	}


	@When("^user enters invalid City$")
	public void user_enters_invalid_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
	//	WebElement checkBox = WebPomRegistration.getCityField();
	//	Select s=new Select(checkBox);
	//	s.selectByVisibleText("");
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	}

	@Then("^display 'Please fill City'$")
	public void display_Please_fill_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select city";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	    
	}

	@When("^user enters invalid State$")
	public void user_enters_invalid_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
		WebElement checkBoxCity = WebPomRegistration.getCityField();
		Select s=new Select(checkBoxCity);
		s.selectByVisibleText("Hyderabad");
		/*WebElement checkBoxState = WebPomRegistration.getCityField();
		Select s1=new Select(checkBoxState);
		s1.selectByVisibleText("");*/
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	   
	}

	@Then("^display 'Please fill the State'$")
	public void display_Please_fill_the_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please select state";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
		WebElement checkBoxCity = WebPomRegistration.getCityField();
		Select s=new Select(checkBoxCity);
		s.selectByVisibleText("Hyderabad");
		WebElement checkBoxState = WebPomRegistration.getStateField();
		Select s1=new Select(checkBoxState);
		s1.selectByVisibleText("Telangana");
		WebElement subjectCategory = WebPomRegistration.getSubjectCategoryField();
		subjectCategory.sendKeys("");
		
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
		
	    
	}

	@Then("^displays 'Please fill the subject category'$")
	public void displays_Please_fill_the_subject_category() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Subject Category";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid Debit Card Number$")
	public void user_enters_invalid_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
		WebElement checkBoxCity = WebPomRegistration.getCityField();
		Select s=new Select(checkBoxCity);
		s.selectByVisibleText("Pune");
		WebElement checkBoxState = WebPomRegistration.getStateField();
		Select s1=new Select(checkBoxState);
		s1.selectByVisibleText("Tamilnadu");
		WebElement subjectCategory = WebPomRegistration.getSubjectCategoryField();
		subjectCategory.sendKeys("Java");
		WebElement paperName=WebPomRegistration.getPaperNameField();
		paperName.sendKeys("");

		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	}

	@Then("^displays 'Please fill Paper names'$")
	public void displays_Please_fill_Paper_names() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill the Paper Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user does not enter CVV value$")
	public void user_does_not_enter_CVV_value() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
		WebElement checkBoxCity = WebPomRegistration.getCityField();
		Select s=new Select(checkBoxCity);
		s.selectByVisibleText("Pune");
		WebElement checkBoxState = WebPomRegistration.getStateField();
		Select s1=new Select(checkBoxState);
		s1.selectByVisibleText("Tamilnadu");
		WebElement subjectCategory = WebPomRegistration.getSubjectCategoryField();
		subjectCategory.sendKeys("Computers");
		WebElement paperName=WebPomRegistration.getPaperNameField();
		paperName.sendKeys("Artifical");
		WebElement noOfAuthors=WebPomRegistration.getAuthorField();
		noOfAuthors.sendKeys("");
	
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	}

	@Then("^displays 'Please fill number of authors'$")
	public void displays_Please_fill_number_of_authors() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Pls. fill the authors";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid expiration month$")
	public void user_enters_invalid_expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
		WebElement checkBoxCity = WebPomRegistration.getCityField();
		Select s=new Select(checkBoxCity);
		s.selectByVisibleText("Hyderabad");
		WebElement checkBoxState = WebPomRegistration.getStateField();
		Select s1=new Select(checkBoxState);
		s1.selectByVisibleText("Tamilnadu");
		WebElement subjectCategory = WebPomRegistration.getSubjectCategoryField();
		subjectCategory.sendKeys("Computers");
		WebElement paperName=WebPomRegistration.getPaperNameField();
		paperName.sendKeys("Artifical");
		WebElement noOfAuthors=WebPomRegistration.getAuthorField();
		noOfAuthors.sendKeys("1");
		WebElement companyName=WebPomRegistration.getCompanyNameField();
		companyName.sendKeys("");
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	   
	}

	@Then("^displays 'Please fill company name'$")
	public void displays_Please_fill_company_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill Company Name";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters invalid expiration year$")
	public void user_enters_invalid_expiration_year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
		WebElement checkBoxCity = WebPomRegistration.getCityField();
		Select s=new Select(checkBoxCity);
		s.selectByVisibleText("Hyderabad");
		WebElement checkBoxState = WebPomRegistration.getStateField();
		Select s1=new Select(checkBoxState);
		s1.selectByVisibleText("Telangana");
		WebElement subjectCategory = WebPomRegistration.getSubjectCategoryField();
		subjectCategory.sendKeys("Computers");
		WebElement paperName=WebPomRegistration.getPaperNameField();
		paperName.sendKeys("Artifical");
		WebElement noOfAuthors=WebPomRegistration.getAuthorField();
		noOfAuthors.sendKeys("1");
		WebElement companyName=WebPomRegistration.getCompanyNameField();
		companyName.sendKeys("Capgemini");
		WebElement designation=WebPomRegistration.getDesignationField();
		designation.sendKeys("");
		WebElement loginButton = WebPomRegistration.submitButton();
		loginButton.click();
	}

	@Then("^displays 'Please fill designation'$")
	public void displays_Please_fill_designation() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		String expectedMessage="Please fill Designation";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^user enters valid  payment details$")
	public void user_enters_valid_payment_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		WebElement userFullName = WebPomRegistration.getFullNameField();
		userFullName.sendKeys("Rasagna");
		WebElement userEmail = WebPomRegistration.getEmailField();
		userEmail.sendKeys("rasagna98@gmail.com");
		WebElement userMobileNo = WebPomRegistration.getPhoneNoField();
		userMobileNo.sendKeys("9515766968");
		WebElement checkBoxCity = WebPomRegistration.getCityField();
		Select s=new Select(checkBoxCity);
		s.selectByVisibleText("Hyderabad");
		WebElement checkBoxState = WebPomRegistration.getStateField();
		Select s1=new Select(checkBoxState);
		s1.selectByVisibleText("Telangana");
		WebElement subjectCategory = WebPomRegistration.getSubjectCategoryField();
		subjectCategory.sendKeys("Computers");
		WebElement paperName=WebPomRegistration.getPaperNameField();
		paperName.sendKeys("Artifical");
		WebElement noOfAuthors=WebPomRegistration.getAuthorField();
		noOfAuthors.sendKeys("1");
		WebElement companyName=WebPomRegistration.getCompanyNameField();
		companyName.sendKeys("Capgemini");
		WebElement designation=WebPomRegistration.getDesignationField();
		designation.sendKeys("Analyst");
		WebElement loginButton = WebPomRegistration.submitButton();
	   
		loginButton.click();
		
		
	    
	}

	@Then("^displays 'Booking Completed!!!'$")
	public void displays_Booking_Completed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions

	}



}
